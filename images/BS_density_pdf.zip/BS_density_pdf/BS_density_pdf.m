clc;clear all;close all;
clear figure;
load('locations.mat'); % load the BS location data in 'km' granulity
region=area; % extract the location matrix in *.mat
x=region(:,1);y=region(:,2); % the x axis and y axis of the whole region
length=4;width=length; % assign the size of small regions
a0=floor(min(x));a1=floor(max(x))+1;b0=floor(min(y));b1=floor(max(y))+1; % determine the edges of the whole region
a=[a0+length/2 a1-length/2 b0+width/2 b1-width/2]; % the actual investigated area avoiding overflow
num=10000; % the number of selected small regions 
record=zeros(num,1); % recording the BS number in each small region
i=1;
while(i<=num), % begin select small regions randomly
    xc=a(1)+(a(2)-a(1))*rand(1,1);yc=a(3)+(a(4)-a(3))*rand(1,1); % select a center point for the small region
    x0=xc-length/2;x1=xc+length/2;y0=yc-width/2;y1=yc+width/2;   % the square edges
    bs_index=find(x>=x0 & x<=x1 & y>=y0 & y<=y1); % the BSs fall into the small region
    record(i)=size(bs_index,1); i=i+1; % record the BS number
end
num_p=record(record>0); % delete the 0 records
record_p=num_p/(length*width); % BS density
bs=max(num_p)-min(num_p)+1; 
bs_pdf=(length*width)*hist(num_p,bs)/size(num_p,1); % pdf of the BS density
bs_dis=(min(num_p):max(num_p))'; 
bs_x=bs_dis/(length*width); % the BS density value samples
bs_pdf=bs_pdf';
%% alpha stable fitting
bs_para=stblfit(record_p,'ecf'); % fitting alpha-stable distribution to real BS density data
alpha=bs_para(1);beta=bs_para(2);stl_sigma=bs_para(3);stl_mu=bs_para(4);
stl_pdf=stblpdf(bs_x,alpha,beta,stl_sigma,stl_mu); % extract the pdf value on the pre-defined density samples
%% poisson fitting
lambda=poissfit(num_p); % discrete fitting
poi_pdf=poisspdf(bs_dis,lambda)*(length*width); % transform the BS number distribution to density PDF
%% Gaussian distribution
[no_mu,no_sigma]=normfit(record_p); 
norm_pdf=normpdf(bs_x,no_mu,no_sigma);
%% lognormal fitting
para_logn=lognfit(record_p);
logn_mu=para_logn(1); logn_sigma=para_logn(2);
logn_pdf=lognpdf(bs_x,logn_mu,logn_sigma);
%% power-law fitting
par_power=gpfit(record_p);
tail=par_power(1);scale=par_power(2);
gp_pdf=gppdf(bs_x,tail,scale);
%% Weibull fitting
para_wbl=wblfit(record_p);
wbl_a=para_wbl(1);wbl_b=para_wbl(2);
wbl_pdf=wblpdf(bs_x,wbl_a,wbl_b);
%% negative bino fitting
%nbin=nbinfit(record);
%nbin_r=nbin(1);nbin_p=nbin(2);
%nbin_pdf=nbinpdf(bs_x,nbin_r,nbin_p);
%% plot pdfs
figure (1);
plot(bs_x,stl_pdf,'ro-','LineWidth',1.5); grid on; hold on; 
plot(bs_x,poi_pdf,'gx-','LineWidth',1.5); grid on; hold on;
plot(bs_x,logn_pdf,'k+-','LineWidth',1.5); grid on; hold on;
plot(bs_x,gp_pdf,'cs-','LineWidth',1.5); grid on; hold on;
plot(bs_x,wbl_pdf,'yd-','LineWidth',1.5); grid on; hold on;
plot(bs_x,bs_pdf,'bh-','LineWidth',1.5); grid on; hold on;
%xlim([0,10]);
grid on;
title('BS density distribution in City B with 3*3 km^2 sample area')
xlabel('BS density (1/km^2)'); ylabel('Probability Density Function (PDF)');
legend('Fitted \alpha-Stable PDF','Fitted Poisson Distribution','Fitted Log-normal PDF','Fitted Generalized Pareto PDF','Fitted Weibull PDF','Real PDF');

figure (2); % log-log plot of the PDF comparison
loglog(bs_x,stl_pdf,'ro-','LineWidth',1.8); grid on; hold on; 
loglog(bs_x,poi_pdf,'gx-','LineWidth',1.8); grid on; hold on;
loglog(bs_x,logn_pdf,'k+-','LineWidth',1.8); grid on; hold on;
loglog(bs_x,gp_pdf,'cs-','LineWidth',1.8); grid on; hold on;
loglog(bs_x,wbl_pdf,'yd-','LineWidth',1.8); grid on; hold on;
loglog(bs_x,bs_pdf,'bh-','LineWidth',1.8); 
xlim([0.2,20]);ylim([0.00001 1]);
grid on;
title('BS density distribution in City B with 4*4 km^2 sample area')
xlabel('BS density (1/km^2)'); ylabel('Probability Density Function (PDF)');
legend('Fitted \alpha-Stable PDF','Fitted Poisson','Fitted Log-normal PDF','Fitted Generalized Pareto PDF','Fitted Weibull PDF','Real PDF');

 rmse_stl=sqrt(mse(bs_pdf-stl_pdf)); % RMSE value of alpha-stable distribution fitting
 rmse_poi=sqrt(mse(bs_pdf-poi_pdf)); % RMSE of Poisson fitting
 rmse_logn=sqrt(mse(bs_pdf-logn_pdf)); % RMSE of lognormal fitting
 rmse_gp=sqrt(mse(bs_pdf-gp_pdf)); % RMSE of Power-law fitting 
 rmse_wbl=sqrt(mse(bs_pdf-wbl_pdf)); % RMSE of Weibull fitting
