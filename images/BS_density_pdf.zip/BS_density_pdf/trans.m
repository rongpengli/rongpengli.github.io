data=xlsread('BS_locations.xlsx','umts'); % read the BS location information (longitude and latitude)
longitude=data(:,1);
latitude=data(:,2);
x0=min(longitude); y0=min(latitude);
x=(longitude-x0)*111.199.*cos(lat*3.14159/180); % transform the (longitude and latitude) to 'km'
y=(latitude-y0)*111.199;
dist=zeros(size(long,1),2);
dist(:,2)=x;dist(:,3)=y;
save('locations.mat',dist);