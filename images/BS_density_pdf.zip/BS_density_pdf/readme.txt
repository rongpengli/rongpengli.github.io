First, the longitude and latitude information of the Base Stations is needed.
Then, running the matlab code 'trans.m' to transform the 'longitude and latitude' to distance information ('km').
At last, running the 'BS_density_pdf.m' to evaluate the fitting performance. 

The xlxs and mat files are provided as examples.

Thanks to the MathWorks community for providing the alpha-stable processing source codes.

https://www.mathworks.com/matlabcentral/fileexchange/37514-stbl--alpha-stable-distributions-for-matlab
